import os
import random
import time
from datetime import datetime
import pandas as pd
import warnings
import requests
from bs4 import BeautifulSoup

warnings.filterwarnings('ignore')

# 显示所有列
pd.set_option('display.max_columns', None)


# 显示所有行
# pd.set_option('display.max_rows', None)


def get_main_info(report_year, report_quarter, notice_day):
    """
    爬取主要的数据
    :param report_year:
    :param report_quarter:
    :param notice_day:
    :return:
    """
    report_data, continue_flag = [], True
    for page_index in range(1, 100):
        if not continue_flag:
            break
        print('[ 提示 ]: 正在爬取第{0}页数据...'.format(page_index))
        page_url = 'http://vip.stock.finance.sina.com.cn/q/go.php/vFinanceAnalyze/kind/performance/index.phtml?' \
                   's_i=&s_a=&s_c=&reportdate={0}&quarter={1}&p={2}'.format(report_year, report_quarter, page_index)
        # 爬取当前页码的数据
        response = requests.get(url=page_url, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/92.0.4515.131 Safari/537.36 SLBrowser/8.0.0.10171 SLBChan/103'})
        report_page, continue_flag = parse_content(response, notice_day)
        report_data.extend(report_page)

        time.sleep(random.randint(2, 5))
    # 数据转为DF
    columns = ['股票代码', '股票链接', '股票名称', '类型', '公告日期', '报告期', '业绩预告摘要', '上年同期每股收益(元)',
               '业绩增幅', '明细', '爬取时间']
    df_data = pd.DataFrame(report_data, columns=columns)

    return df_data


def parse_content(response, notice_day):
    """
    解析网页内容
    :param page_source:
    :return:
    """
    response.encoding = "gbk"
    soup = BeautifulSoup(response.text, 'html.parser')
    # 定位到具体的标签
    target_tr = soup.find(class_='list_table').find_all('tr')

    report_page, continue_flag = [], True
    # 遍历标签，获取每一个tr的数据
    for tr in target_tr[1:]:
        report_per = []
        for td, td_index in zip(tr.find_all('td'), range(len(tr.find_all('td')))):
            report_per.append(td.get_text().replace("\n", ''))
            if td_index == 0:
                report_per.append(td.find('a').get('href'))
        report_per.append(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        # 如果当前日期小于所需的报告日期，则退出
        if report_per[4] < notice_day:
            continue_flag = False
            break
        elif report_per[4] == notice_day:
            report_page.append(report_per)

    return report_page, continue_flag


def resolve_ratio(data):
    """
    解析业绩增幅列
    :param data:
    :return:
    """
    if '~' in data:
        low_ratio = data.split('~')[0].replace('%', '')
        high_ratio = data.split('~')[1].replace('%', '')
    else:
        low_ratio, high_ratio = data, data

    return [low_ratio, high_ratio]


def process_df(df_data):
    """
    对DF进行简单处理
    :return:
    """
    df_data['股票代码'] = df_data['股票代码'].apply(lambda x: 'd_' + str(x))
    df_data['业绩增幅'] = df_data['业绩增幅'].apply(lambda x: resolve_ratio(x))
    split_df = df_data['业绩增幅'].apply(lambda x: pd.Series(x))
    split_df.columns = ['业绩增幅-最低(%)', '业绩增幅-最高(%)']
    df_result = pd.concat([df_data, split_df], axis=1)
    df_result.drop(['明细', '业绩增幅'], axis=1, inplace=True)

    return df_result


if __name__ == '__main__':
    # 需要手动设置，对应的 report_quarter 即为每个季度的数据
    report_year, report_quarter = '2022', '4'
    # 截止当前日期
    notice_day = '2022-10-29'

    # 创建文件夹
    dirname = "业绩预告"
    if not os.path.exists(dirname):
        os.mkdir(dirname)
        print('[ 提示 ]: 创建文件夹 {0} 成功，爬取数据中...'.format(dirname))
    # 爬取数据
    df_stock_info = get_main_info(report_year, report_quarter, notice_day)
    # 对数据进行简单的处理
    print('======>> 爬取完成，处理数据中......')
    df_stock_info = process_df(df_stock_info)
    # 导出成本地csv
    save_filepath = os.path.join(dirname, notice_day + '.csv')
    df_stock_info.to_csv(save_filepath, index=False, encoding='gbk')
    print('======>> 处理完成，已导出本地：{0}'.format(save_filepath))
